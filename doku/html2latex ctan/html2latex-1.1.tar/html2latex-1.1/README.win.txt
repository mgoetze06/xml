You can put html2latex anywhere you want.  Putting in your path makes
command-line usage very easy, however.  Also, read HTML/README.win.txt
for special instructions in installing HTML::Latex on Windows
machines.
